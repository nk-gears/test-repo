const axios = require("axios");

const processRequest = function(event, context, callback) {
  let extUrl=event.headers["host"] // "credit-planner-api.or
  let respData={};
  axios
    .get(extUrl)
    .then(function(d) {
      respData=d.data;

        //Add this for CORS if needed
        const response = {
        statusCode: 200,
        headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Credentials": true
        },
        body: JSON.stringify({ data: respData })
        };
        callback(null, response);

    })
    .catch(e => {
      // res.status(400).json({ msg: e });
    });


};

exports.handler=processRequest;